from flask import Flask, render_template, request, redirect, url_for, session
from crud_postgres import (
    buscar_todas_pessoas, buscar_pessoa_por_id, inserir_pessoa,
    atualizar_pessoa, deletar_pessoa, buscar_por_login_senha, inserir_usuario, buscar_por_nome, buscar_livros
)
from flask_bcrypt import Bcrypt

app = Flask(__name__)
app.secret_key = 'chave_secreta'
bcrypt = Bcrypt(app)

# Rotas estáticas para páginas HTML simples
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/campi')
def campi():
    return render_template('campi.html')

@app.route('/pesquisa_extensao')
def pesquisa_extensao():
    return render_template('pesquisa-e-extensao.html')

@app.route('/contato')
def contato():
    return render_template('contato.html')

@app.route('/acesso_biblioteca')
def acesso_biblioteca():
    return render_template('acesso-biblioteca.html')

@app.route('/biblioteca')
def biblioteca():
    # busca os livros ou qualquer lógica que precisar
    livros = buscar_livros(
        titulo=request.args.get('titulo'),
        isbn=request.args.get('isbn'),
        autor=request.args.get('autor')
    )
    return render_template('biblioteca.html')

# Login e cadastro
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login_form = request.form['login']
        senha = request.form['password']
        usuario = buscar_por_login_senha(login_form)
        if usuario and bcrypt.check_password_hash(usuario['senha'], senha):
            session['usuario'] = usuario['nome']
            # Redirecionar conforme cargo
            if usuario.get('cargo') == 'aluno':
                return redirect(url_for('portal_aluno'))
            elif usuario.get('cargo') == 'professor':
                return redirect(url_for('portal_professor'))
            else:
                return redirect(url_for('listar_pessoas_rota'))
        return "Login inválido", 401
    return render_template('login.html')

@app.route('/cadastro', methods=['POST'])
def cadastro():
    nome = request.form['nome']
    email = request.form['email']
    login_form = request.form['login']
    senha = bcrypt.generate_password_hash(request.form['senha']).decode('utf-8')
    cargo = request.form['cargo']
    siape = request.form.get('siape')
    inserir_usuario(nome, email, login_form, senha, cargo, siape)
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('usuario', None)
    return redirect(url_for('login'))

# Portais do aluno e professor
@app.route('/portal-aluno')
def portal_aluno():
    if 'usuario' not in session:
        return redirect(url_for('login'))
    return render_template('portal-aluno.html')

@app.route('/portal-professor')
def portal_professor():
    if 'usuario' not in session:
        return redirect(url_for('login'))
    
    usuario_nome = session['usuario']
    professor = buscar_por_nome(usuario_nome)
    
    return render_template('portal-professor.html', professor=professor)

# CRUD Pessoas
@app.route('/pessoas')
def listar_pessoas_rota():
    lista = buscar_todas_pessoas()
    return render_template('pessoas.html', pessoas=lista)

@app.route('/pessoa/nova')
def nova_pessoa():
    return render_template('form_pessoa.html')

@app.route('/pessoa/salvar', methods=['POST'])
def salvar_pessoa():
    dados = (
        request.form['nome'],
        request.form.get('email'),
        request.form.get('telefone'),
        request.form['cargo'],
        request.form.get('login'),
        request.form.get('siape'),
        request.form.get('titulacao'),
        request.form.get('data_contratacao'),
        request.form.get('foto')
    )
    inserir_pessoa(*dados)
    return redirect(url_for('listar_pessoas_rota'))

@app.route('/pessoa/<int:id>')
def ver_pessoa(id):
    pessoa = buscar_pessoa_por_id(id)
    if pessoa:
        return render_template('ver_pessoa.html', pessoa=pessoa)
    return "Pessoa não encontrada", 404

@app.route('/pessoa/editar/<int:id>')
def editar_pessoa(id):
    pessoa = buscar_pessoa_por_id(id)
    if pessoa:
        return render_template('form_pessoa.html', pessoa=pessoa)
    return "Pessoa não encontrada", 404

@app.route('/pessoa/atualizar/<int:id>', methods=['POST'])
def atualizar(id):
    dados = (
        request.form['nome'],
        request.form.get('email'),
        request.form.get('telefone'),
        request.form['cargo'],
        request.form.get('login'),
        request.form.get('siape'),
        request.form.get('titulacao'),
        request.form.get('data_contratacao'),
        request.form.get('foto')
    )
    atualizar_pessoa(id, *dados)
    return redirect(url_for('ver_pessoa', id=id))

@app.route('/pessoa/deletar/<int:id>')
def deletar(id):
    deletar_pessoa(id)
    return redirect(url_for('listar_pessoas_rota'))


if __name__ == '__main__':
    app.run(debug=True)
