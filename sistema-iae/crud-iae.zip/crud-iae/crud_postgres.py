import psycopg2
from psycopg2.extras import RealDictCursor


config = {
    "dbname": "bd_user2",
    "user": "user2",
    "password": "senha123user2",
    "host": "54.88.225.140",
    "port": "5432"
}

def buscar_todas_pessoas():
    conn = psycopg2.connect(**config)
    cur = conn.cursor()
    cur.execute("SELECT * FROM pessoas ORDER BY nome")
    dados = []
    for r in cur.fetchall():
        dados.append({
            "id": r[0], "nome": r[1], "email": r[2], "telefone": r[3],
            "cargo": r[4], "login": r[5], "siape": r[6],
            "titulacao": r[7], "data_contratacao": r[8], "foto": r[9],
            "matricula": r[10], "curso": r[11], "departamento": r[12],
            "status": r[13], "data_nascimento": r[14], "genero": r[15],
            "cpf": r[16], "observacoes": r[17]
        })
    cur.close()
    conn.close()
    return dados

def buscar_pessoa_por_id(id):
    conn = psycopg2.connect(**config)
    cur = conn.cursor()
    cur.execute("SELECT * FROM pessoas WHERE id = %s", (id,))
    r = cur.fetchone()
    cur.close()
    conn.close()
    if r:
        return {
            "id": r[0], "nome": r[1], "email": r[2], "telefone": r[3],
            "cargo": r[4], "login": r[5], "siape": r[6],
            "titulacao": r[7], "data_contratacao": r[8], "foto": r[9]
        }
    return None

def inserir_pessoa(nome, email, telefone, cargo, login, siape, titulacao, data_contratacao, foto):
    conn = psycopg2.connect(**config)
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO pessoas
        (nome, email, telefone, cargo, login, siape, titulacao, data_contratacao, foto)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (nome, email, telefone, cargo, login, siape, titulacao, data_contratacao, foto))
    conn.commit()
    cur.close()
    conn.close()

def atualizar_pessoa(id, nome, email, telefone, cargo, login, siape, titulacao, data_contratacao, foto):
    conn = psycopg2.connect(**config)
    cur = conn.cursor()
    cur.execute("""
        UPDATE pessoas SET
            nome = %s, email = %s, telefone = %s, cargo = %s,
            login = %s, siape = %s, titulacao = %s,
            data_contratacao = %s, foto = %s
        WHERE id = %s
    """, (nome, email, telefone, cargo, login, siape, titulacao, data_contratacao, foto, id))
    conn.commit()
    cur.close()
    conn.close()

def deletar_pessoa(id):
    conn = psycopg2.connect(**config)
    cur = conn.cursor()
    cur.execute("DELETE FROM pessoas WHERE id = %s", (id,))
    conn.commit()
    cur.close()
    conn.close()

# Exemplo de função, você adapta conforme seu crud_postgres.py
def buscar_por_login_senha(login):
    conn = psycopg2.connect(
        host="54.88.225.140",
        database="bd_user2",
        user="user2",
        password="senha123user2"
    )
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute("SELECT id, nome, senha, cargo FROM pessoas WHERE login = %s", (login,))
            row = cursor.fetchone()
            if row:
                return row  # Já é dict por causa do RealDictCursor
            else:
                return None
    finally:
        conn.close()

def inserir_usuario(nome, email, login, senha, cargo, siape):
    conn = psycopg2.connect(**config)
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO pessoas (nome, email, login, senha, cargo, siape)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (nome, email, login, senha, cargo, siape))
    conn.commit()
    cur.close()
    conn.close()

def buscar_por_nome(nome):
    conn = psycopg2.connect(**config)
    cur = conn.cursor()
    cur.execute("SELECT nome, siape, login, departamento, titulacao, email, telefone, data_contratacao FROM pessoas WHERE nome = %s", (nome,))
    r = cur.fetchone()
    cur.close()
    conn.close()
    if r:
        return {
            "nome": r[0],
            "siape": r[1],
            "login": r[2],
            "departamento": r[3],
            "titulacao": r[4],
            "email": r[5],
            "telefone": r[6],
            "data_contratacao": r[7]
        }
    return None

def buscar_livros(titulo=None, isbn=None, autor=None):
    todos_livros = [
        {'id': 1, 'titulo': 'Dom Casmurro', 'autor': 'Machado de Assis', 'isbn': '123'},
        {'id': 2, 'titulo': 'O Cortiço', 'autor': 'Aluísio Azevedo', 'isbn': '456'},
    ]

    resultado = []
    for l in todos_livros:
        if (
            (not titulo or titulo.lower() in l['titulo'].lower()) and
            (not isbn or isbn in l['isbn']) and
            (not autor or autor.lower() in l['autor'].lower())
        ):
            resultado.append(l)

    return resultado

def buscar_professor_por_id(professor_id):
    # Aqui você busca o professor no banco e retorna um objeto ou dicionário
    # Exemplo fictício:
    return {
        "nome": "João Silva",
        "siape": "1234567",
        "login": "jsilva",
        "ultimo_acesso": "15/06/2025",
        "departamento": "Engenharia de Software",
        "titulacao": "Doutor em Computação",
        "email": "joao.silva@universidade.br",
        "telefone": "(31) 99876-5432",
        "data_contratacao": "01/03/2018",
        "tempo_servico": "7 anos e 3 meses"
    }

def buscar_aluno_por_id(aluno_id):
    # Similar para aluno
    return {
        "nome": "Vicente",
        "matricula": "2023123456",
        "login": "vesoares",
        "ultimo_acesso": "Hoje",
        "genero": "Masculino",
        "nome_social": "Vicente Eduardo Soares",
        "cpf": "123.456.789-00",
        "data_nascimento": "04/12/2003",
        "idade": "21 anos",
        "curso": "Engenharia de Software",
        "turno": "Manhã",
        "periodo": "1º Período",
        "modalidade": "Presencial"
    }



