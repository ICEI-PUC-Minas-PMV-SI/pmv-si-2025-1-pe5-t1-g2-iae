import psycopg2

config = {
    "dbname": "bd_user2",
    "user": "user2",
    "password": "senha123user2",
    "host": "13.218.21.71",
    "port": "5432"
}

try:
    conn = psycopg2.connect(**config)
    print("Conectado com sucesso!")
    conn.close()
except Exception as e:
    print(f"Erro na conexão: {e}")


