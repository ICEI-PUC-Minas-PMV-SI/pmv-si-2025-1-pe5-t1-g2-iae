document.addEventListener('DOMContentLoaded', () => {
  const tabs = document.querySelectorAll('.login-tab');
  const loginInput = document.getElementById('login');
  const passwordInput = document.getElementById('password');
  const loginForm = document.getElementById('login-form');
  const loginBox = document.querySelector('.login-box');

  const defaults = {
    aluno:     { login: 'vesoares', password: '********' },
    professor: { login: 'jsilva',   password: '********' }
  };

  function switchTab(tab) {
    // Ativa visualmente a aba clicada
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');

    // Alterna conteúdo visível
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    const target = tab.dataset.tab;
    const content = document.getElementById(`${target}-form`);
    if (content) content.classList.add('active');

    // Alterna classe no login-box para aplicar o estilo de cadastro
    if (target === 'cadastro') {
      loginBox.classList.add('cadastro-ativo');
    } else {
      loginBox.classList.remove('cadastro-ativo');
    }

    // Preenche login e senha de exemplo (somente para tabs com dados fictícios)
    if (defaults[target]) {
      loginInput.value = defaults[target].login;
      passwordInput.value = defaults[target].password;
    }
  }

  // Inicializa a aba ativa
  const initialTab = document.querySelector('.login-tab.active') || tabs[0];
  switchTab(initialTab);

  // Adiciona eventos de clique a cada aba
  tabs.forEach(tab => {
    tab.addEventListener('click', () => switchTab(tab));
  });
});
