document.addEventListener('DOMContentLoaded', function () {
  const tabs = document.querySelectorAll('.campus-tab');
  const contents = document.querySelectorAll('.campus-content');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.getAttribute('data-tab');

      // Remove 'active' de todas as abas e conteúdos
      tabs.forEach(t => t.classList.remove('active'));
      contents.forEach(c => c.classList.remove('active'));

      // Adiciona 'active' na aba clicada e no conteúdo correspondente
      tab.classList.add('active');
      document.getElementById(target).classList.add('active');
    });
  });
});
